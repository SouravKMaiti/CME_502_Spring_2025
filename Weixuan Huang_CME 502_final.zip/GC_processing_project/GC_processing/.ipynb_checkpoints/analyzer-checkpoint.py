#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd 

def compute_conversion_selectivity(gc_df:pd.DataFrame, config:dict)->pd.DataFrame:
    inlet_gas = config["GC_plot"]["inlet_gas"]
    main_product = config["GC_plot"]["main_product"]
    carbon_dict = config["GC_carbon_content"]
    species_map = config["GC_dict"]
    inlet_col =species_map[inlet_gas]
    product_col = species_map[main_product]
    #carbon outflow
    total_carbon_out = pd.Series(0,index=gc_df.index,dtype=float)
    for species, col in species_map.items():
        if species in carbon_dict:
            total_carbon_out += gc_df.get(col,0)*carbon_dict[species]
    #conversion
    conversion = (gc_df[inlet_col] - gc_df[product_col]) / gc_df[inlet_col]
    conversion = conversion.clip(lower=0)
    #selectivity
    selectivity = gc_df[product_col]*carbon_dict[main_product]/total_carbon_out
    selectivity = selectivity.clip(lower=0,upper=1)

    result_df = pd.DataFrame({"conversion": conversion,"selectivity":selectivity}, index = gc_df.index)

    return result_df
    


# In[ ]:




