#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import os 
import toml
import pandas as pd
from glob import glob

#loading configurations and GC settings 

def load_gc_config(config_path,factor_path):
    config = toml.load(config_path)
    gc_config = toml.load(factor_path)
    return config, gc_config

#acquiring GC folders

def collect_gc_files(config):
    base_dir = config["file"]["data_dir"]
    gc_dirs = []

    for name in os.listdir(base_dir):
        path = os.path.join(base_dir, name)
        if os.path.isdir(path) and name.endswith(".D"):
            if os.path.exists(os.path.join(path, "TCD2B.ch")):
                gc_dirs.append(path)
    return gc_dirs


#save GC areas to CSV

def save_gc_dataframe(df,config):
    output_dir=config["file"]["output_dir"]
    os.makedirs(output_dir, exist_ok=True)
    output_path =os.path.join(output_dir,f"{config['experiment']['id']}_GC_raw_area.csv")
    df.to_csv(output_path)
    print(f"saved raw GC area table to output_path")

#loading reactor information

def load_reactor_data(config):
    paths=config["file"]["reactor"]
    dfs=[]
    for path_pattern in paths:
        for path in glob(path_pattern):
            df=pd.read_csv(path,index_col=0,parse_dates=True)
            dfs.append(df)

    if dfs:
        return pd.concat(dfs).sort_index()
    else:
        return pd.DataFrame()


# In[ ]:




