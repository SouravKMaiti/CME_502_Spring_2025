{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 11,
   "id": "d61ccdc0-4ae2-4bf6-8033-555554c26fef",
   "metadata": {},
   "outputs": [
    {
     "ename": "ModuleNotFoundError",
     "evalue": "No module named 'parser'",
     "output_type": "error",
     "traceback": [
      "\u001b[1;31m---------------------------------------------------------------------------\u001b[0m",
      "\u001b[1;31mModuleNotFoundError\u001b[0m                       Traceback (most recent call last)",
      "Cell \u001b[1;32mIn[11], line 6\u001b[0m\n\u001b[0;32m      4\u001b[0m \u001b[38;5;28;01mimport\u001b[39;00m \u001b[38;5;21;01mtoml\u001b[39;00m\n\u001b[0;32m      5\u001b[0m \u001b[38;5;28;01mimport\u001b[39;00m \u001b[38;5;21;01mpandas\u001b[39;00m \u001b[38;5;28;01mas\u001b[39;00m \u001b[38;5;21;01mpd\u001b[39;00m\n\u001b[1;32m----> 6\u001b[0m \u001b[38;5;28;01mfrom\u001b[39;00m \u001b[38;5;21;01mparser\u001b[39;00m \u001b[38;5;28;01mimport\u001b[39;00m GC_concentration\n\u001b[0;32m      7\u001b[0m \u001b[38;5;28;01mfrom\u001b[39;00m \u001b[38;5;21;01mio_handler\u001b[39;00m \u001b[38;5;28;01mimport\u001b[39;00m load_gc_config, collect_gc_files, save_gc_dataframe,load_reactor_data\n\u001b[0;32m      8\u001b[0m \u001b[38;5;28;01mfrom\u001b[39;00m \u001b[38;5;21;01manalyzer\u001b[39;00m \u001b[38;5;28;01mimport\u001b[39;00m compute_conversion_selectivity\n",
      "\u001b[1;31mModuleNotFoundError\u001b[0m: No module named 'parser'"
     ]
    }
   ],
   "source": [
    "import os\n",
    "import toml\n",
    "import pandas as pd\n",
    "from parser import GC_concentration\n",
    "from io_handler import load_gc_config, collect_gc_files, save_gc_dataframe,load_reactor_data\n",
    "from analyzer import compute_conversion_selectivity\n",
    "from concentration import convert_area_to_concentration\n",
    "import matplotlib.pyplot as plt\n",
    "import numpy as np\n",
    "\n",
    "# loading configuraion file\n",
    "CONFIG_PATH = \"./config/config.toml\"\n",
    "FACTOR_PATH = \"./config/20230803_GC_factor.toml\"\n",
    "config, gc_config = load_gc_config(CONFIG_PATH,FACTOR_PATH)\n",
    "\n",
    "#Extract GC peak areas (TCD)\n",
    "gc_files= collect_gc_files(config)\n",
    "gc_df=[]\n",
    "for gc_dir in gc_files:\n",
    "    print(f\"processing: {gc_dir}\")\n",
    "    spectrum = GC_concentration(gc_dir, FACTOR_PATH, mode=\"TCD\")\n",
    "    data_series = spectrum.raw_peak_areas()\n",
    "    data_series[\"datetime\"] = spectrum.timestamp\n",
    "    gc_df.append(data_series)\n",
    "\n",
    "gc_df =pd.DataFrame(gc_df)\n",
    "gc_df.set_index(\"datetime\", inplace=True)\n",
    "\n",
    "#Save raw peak area to a table\n",
    "save_gc_dataframe(gc_df,config)\n",
    "\n",
    "#Convert area to concentration\n",
    "conc_df = convert_area_to_concentration(gc_df,FACTOR_PATH)\n",
    "conc_path = os.path.join(config[\"file\"][\"output_dir\"],f\"{config['experiment']['id']}_GC_concentration.csv\")\n",
    "conc_df.to_csv(conc_path)\n",
    "\n",
    "#load reactor data\n",
    "print(f\"Concentration data saved to {conc_path}\")\n",
    "reactor_df = load_reactor_data(config)\n",
    "\n",
    "#Merge GC and reactor data \n",
    "merged_df = pd.merge(conc_df,reactor_df,left_index=True,right_index=True,how=\"outer\")\n",
    "merged_df.sort_index(inplace=True)\n",
    "merged_df.interpolate(method=\"linear\", inplace=True)\n",
    "\n",
    "#conversion and selectivity \n",
    "result_df = compute_conversion_selectivity(merged_df,config)\n",
    "result_path = os.path.join(config[\"file\"][\"output_dir\"],f\"{config['experiment']['id']}_GC_analysis_result.csv\")\n",
    "result_df.to_csv(result_path)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "0aae8d58-64ef-455d-9805-68c7c52fde7b",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python [conda env:base] *",
   "language": "python",
   "name": "conda-base-py"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.12.7"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
