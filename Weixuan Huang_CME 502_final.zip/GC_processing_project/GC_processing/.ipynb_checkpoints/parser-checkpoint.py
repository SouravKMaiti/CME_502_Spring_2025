#!/usr/bin/env python
# coding: utf-8

# In[ ]:

import os 
import toml
from datetime import datetime 
from time import mktime
from PyExpLabSys.file_parsers import chemstation
from scipy.optimize import least_squares
from scipy.signal import find_peaks
from scipy.special import erf
from scipy.stats import linregress
import numpy as np
import pandas as pd
import pybaselines
import matplotlib.pyplot as plt


#GC spectrum process
class GCSpectrum: # class is more like a collection of functions. With class we don't need to creates .py modules to read each .ch files and accessory information relate to each .ch file 
    def __init__(self, filepath, ignore_baseline):
        self.CH = chemstation.CHFile(filepath)#use pyExpLabSys to read .ch files 
        self.datetime = datetime.fromtimestamp(mktime(self.CH.metadata["datetime"]))# translate related metadata to datetime
        self.timestamp = self.datetime.timestamp()
        self.y = self.CH.values #array of TCD values 
        self.x = np.linspace(self.CH.metadata["start_time"], self.CH.metadata["end_time"], len(self.y))# x-axis contrunction (time)
        self.freq = 1 / (self.x[1] - self.x[0])
        self.correct_baseline(ignore_baseline)# correct baseline 

#baseline correction using whittaker smoothing 
    def correct_baseline(self,ignore_list,lam=1e10,niter=100):
        mask=np.ones_like(self.x,dtype=bool) 
        for region in ignore_list:
            mask &=~ ((self.x>=region[0])&(self.x<=region[1]))#disconsidering the regions where peaks emerges
        baseline,_=pybaselines.whittaker.iarpls(self.y[mask],lam=lam,max_iter=niter)#whittaker smoothing
        self.baseline =np.interp(self.x,self.x[mask],baseline)#whittaker smoothing extend into the region where peaks are located
        self.y_corrected =self.y - self.baseline #denoise the peaks 

#peak detect and fit using skewed Gaussian fitting 
    def peak_fit(self):
        prominence =0.02*np.std(self.y_corrected)#define the standard of peak in the signal (prominence)
        peaks,props= find_peaks(self.y_corrected,prominence=prominence)#find peaks 

        def model(x,x0,ph,w,sk):#defining skrewed Gaussian function
            e=(x-x0)/w
            return ph*(1+erf(sk*e))*np.exp(-e*e)

        def fit_error(p,x,y):
            return model(x,*p)-y
            
        self.fitted_params = []
        self.fitted_curves = []
        self.raw_areas = []
        self.fitted_areas = []
       
        for i in peaks:
            x0=self.x[i]
            ph=self.y_corrected[i]
            w=0.01
            sk=0
            bounds=([x0-0.1,0,0.001,-5],[x0+0.1,10*ph,0.1,5])#standard for determining peak center. The discovered peaks are compared with the peak center given by the .ch file. deviation may apply, but limiation is +-0.1
            res=least_squares(fit_error,[x0,ph,w,sk],args=(self.x,self.y_corrected),bounds=bounds)
            self.fitted_params.append(res.x)
            self.fitted_curves.append(model(self.x,*res.x))
#fitted area
            fitted_area=res.x[1]*res.x[2]*np.sqrt(np.pi)/self.freq
            raw_area=np.trapz(self.y[i-5:i+5],self.x[i-5:i+5])
            self.fitted_areas.append(fitted_area)
            self.raw_areas.append(raw_area)

#R2 calculation (initial design for R2 calculation, but not saved to he CSV)
        #if len(self.raw_areas) >=2:
         #   r2 =linregress(self.raw_areas,self.fitted_areas).rvalue**2
          #  print(f"R² between raw and fitted areas: {r2:.4f}")
#peak fitting 
    def get_peak_table(self):
        df=pd.DataFrame(columns=["area","center","width","height"])
        for p in self.fitted_params:
            x0,ph,w,sk=p
            area=ph*w*np.sqrt(np.pi)/self.freq
            df.loc[len(df)]=[area,x0,w,ph]
        return df

#plotting fitted and raw peak areas in a table  
    def plot_peaks(self, output_path, title=None):
      import matplotlib.pyplot as plt

# generating new plotting canvas 
      plt.figure(figsize=(10, 4))

#ploting  raw peak 
      plt.plot(self.x, self.y, label="Raw Signal", color="gray")

# plotting fitted peak 
      for i, fit in enumerate(self.fitted_curves):
          plt.plot(self.x, fit, linestyle="--", label="Fitted Peak" if i == 0 else None)

      plt.xlabel("Time (min)")
      plt.ylabel("Signal (a.u.)")
    
      if title:
          plt.title(title)

      plt.legend()
      plt.tight_layout()
      plt.savefig(output_path)
      plt.close()  # close the current canvas 


#managing GC file (.ch file) and config.toml file accessing for information other than peaks like dates, retention time, temperature... 
class GC_concentration:
    def __init__(self, data_dir, gc_factor_file, mode="TCD"):
        self.data_dir=data_dir
        self.mode=mode
        self.gc_config=toml.load(gc_factor_file)
        self.retention_time=self.gc_config["retention"]
        self.ignore_baseline_list=self.gc_config["baseline"]["ignore_baseline"]
        self.read_gc_file()
        self.timestamp=self.spectrum.timestamp

#select and read GC file (reading .ch file for peak infor. eg retention time, peak center, width, area ...)
    def read_gc_file(self):
        if self.mode=="TCD":
            filename="TCD2B.ch"
        elif self.mode=="FID":
            filename="FID1A.ch"
        else:
            raise ValueError("Unknown File.")
        filepath=os.path.join(self.data_dir,filename)
        self.spectrum=GCSpectrum(filepath,self.ignore_baseline_list)
        self.raw_spectrum = GCSpectrum(filepath, self.ignore_baseline_list)
        self.spectrum.peak_fit()
        self.df_peaks=self.spectrum.get_peak_table()

# Extract metadata from folder name or config if needed (I am still not familiar with "metadata", I think it is the information other than peak center,width, area, but related to this .ch file time, temperature...)
        label = os.path.basename(self.data_dir)
        temp = self.gc_config.get("meta", {}).get(label, {}).get("temperature", None)
        flow = self.gc_config.get("meta", {}).get(label, {}).get("flow", None)
        fig_name = f"{label}"
        if temp: fig_name += f"_T{temp}"
        if flow: fig_name += f"_F{flow}"
        self.spectrum.plot_peaks(output_path=os.path.join(self.data_dir, f"{fig_name}.png"))
        plt.close()

#Raw peak area
    def raw_peak_areas(self):
        df=pd.Series(dtype=float)
        for i ,row in self.df_peaks.iterrows():
            df[f"peak{i}_area"] = row["area"]
            df[f"peak{i}_raw_area"] = self.spectrum.raw_areas[i]

#R2 calculation (between raw peaks and fitted peaks )            
        if hasattr(self.spectrum,"raw_areas") and len(self.spectrum.raw_areas) >=2:
            from scipy.stats import linregress
            r2=linregress(self.spectrum.raw_areas,self.spectrum.fitted_areas).rvalue**2
            df["fit_r_squared"]=r2
        return df












    


# In[ ]:




