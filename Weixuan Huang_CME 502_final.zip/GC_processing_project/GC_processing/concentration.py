#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import pandas as pd
import toml

def convert_area_to_concentration(area_df: pd.DataFrame, factor_path:str) -> pd.DataFrame:
    config = toml.load(factor_path)
    tcd_factors = config["TCD_factor"]
    rt_map = config["retention"]
    conc_df = pd.DataFrame(index=area_df.index)

    for compound, rt in rt_map.items():
        best_match = None
        min_diff = float("inf")
        for col in area_df.columns:
            if col.endswith("center"):
                diff = (area_df[col]-rt).abs().mean()
                if diff < min_diff:
                    min_diff=diff
                    best_match =col
    
        if best_match:
            area_col = best_match.replace("center","area")
            factor = tcd_factors.get(compound,0)
            conc_df[f"{compound}_TCD"] =area_df[area_col]*factor
    
    return conc_df


# In[ ]:




