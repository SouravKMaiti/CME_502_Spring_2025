please use the main.ipynb to run the program. all the programs are located at GC processing folder 

For .ch files, I only find a few files with evident CO2 signals in our previous experiments. 
It was mainly used for CO2 calibration, so only CO2 was injected into the system, no reactions took place and, unfortunately, I cannot demonstrate conversion and selectivity results. But GC peaks are calculated, converted to concentration(%) and fitted. fitted peaks and .csv files are located in the output folder. 